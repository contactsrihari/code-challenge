# Capacity Test API (Spring Boot 3, Java 17, Gradle 8)

A ready-to-run example showing:
- Swagger/OpenAPI 3 documentation (springdoc)
- A POST endpoint that accepts an **array of objects**, iterates them,
  calls a **downstream REST endpoint** for each, and aggregates responses.
- Layered packages under `com.citi.td.capacity.test.*`
- A **mock downstream** endpoint in the same app (for easy testing).

## Build & Run (Linux)

### Prerequisites
- JDK 17
- Gradle 8+ (or use Docker below)

### CLI
```bash
# From the project root
gradle clean build

# Run
gradle bootRun
# OR
java -jar build/libs/capacity-test-1.0.0.jar
```

### Docker (no local Gradle needed)
```bash
# Build the image
docker build -t capacity-test:1.0 .

# Run it
docker run --rm -p 8080:8080 capacity-test:1.0
```

## Swagger UI
Once running, open:
- http://localhost:8080/swagger-ui/index.html

## Test the POST endpoint
```bash
curl -X POST 'http://localhost:8080/api/requests'   -H 'Content-Type: application/json'   -d '[{"id":"1","payload":"alpha"},{"id":"2","payload":"beta"}]'
```

You should see a JSON array of results. The service will call the **mock downstream**
endpoint by default (configurable via `application.yml`).

## Config
Set downstream service in `src/main/resources/application.yml`:

```yaml
downstream:
  base-url: http://localhost:8080
  path: /mock/echo
```

You can change these to point to a real service.
