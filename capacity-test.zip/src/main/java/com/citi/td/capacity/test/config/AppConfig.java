package com.citi.td.capacity.test.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class AppConfig {

    @Value("${downstream.base-url}")
    private String downstreamBaseUrl;

    @Bean
    public WebClient webClient(WebClient.Builder builder) {
        // Increase default memory limits for large payloads if needed
        ExchangeStrategies strategies = ExchangeStrategies.builder()
                .codecs(cfg -> cfg.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
                .build();
        return builder
                .exchangeStrategies(strategies)
                .baseUrl(downstreamBaseUrl)
                .build();
    }
}
