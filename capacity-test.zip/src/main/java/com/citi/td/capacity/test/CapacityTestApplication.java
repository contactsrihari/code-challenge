package com.citi.td.capacity.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapacityTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(CapacityTestApplication.class, args);
    }
}
