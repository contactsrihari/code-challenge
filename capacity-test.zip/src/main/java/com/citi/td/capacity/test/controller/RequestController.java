package com.citi.td.capacity.test.controller;

import com.citi.td.capacity.test.dto.InputRequest;
import com.citi.td.capacity.test.dto.OutputResponse;
import com.citi.td.capacity.test.service.RequestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/requests", produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "Requests", description = "Submit array of requests; each is sent to a downstream REST endpoint")
@Validated
public class RequestController {

    private final RequestService requestService;

    public RequestController(RequestService requestService) {
        this.requestService = requestService;
    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Submit array of requests and get aggregated downstream responses")
    public List<OutputResponse> handleRequests(@Valid @RequestBody List<@Valid InputRequest> requests) {
        return requestService.processRequests(requests);
    }
}
