package com.citi.td.capacity.test.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/mock", produces = MediaType.APPLICATION_JSON_VALUE)
public class MockDownstreamController {

    @PostMapping(path = "/echo", consumes = MediaType.APPLICATION_JSON_VALUE)
    public String echo(@RequestBody String body) {
        // Simulate some processing and return a JSON string
        return "{\"echo\":\""+ body.replace("\\", "\\\\").replace("\"", "\\\\"") + "\",\"processed\":true}";
    }
}
