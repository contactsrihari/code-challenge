package com.citi.td.capacity.test.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class DownstreamClient {

    private final WebClient webClient;

    @Value("${downstream.path}")
    private String downstreamPath;

    public DownstreamClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public String callDownstream(String payload) {
        // Block for simplicity; replace with reactive composition if desired
        return webClient.post()
                .uri(downstreamPath)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(payload)
                .retrieve()
                .bodyToMono(String.class)
                .onErrorResume(e -> Mono.just("ERROR: " + e.getMessage()))
                .block();
    }
}
