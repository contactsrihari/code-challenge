package com.citi.td.capacity.test.dto;

public class OutputResponse {

    private String id;
    private String status;
    private String downstreamResult;

    public OutputResponse() {}

    public OutputResponse(String id, String status, String downstreamResult) {
        this.id = id;
        this.status = status;
        this.downstreamResult = downstreamResult;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getDownstreamResult() {
        return downstreamResult;
    }
    public void setDownstreamResult(String downstreamResult) {
        this.downstreamResult = downstreamResult;
    }
}
