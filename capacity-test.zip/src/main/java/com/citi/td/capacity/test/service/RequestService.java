package com.citi.td.capacity.test.service;

import com.citi.td.capacity.test.client.DownstreamClient;
import com.citi.td.capacity.test.dto.InputRequest;
import com.citi.td.capacity.test.dto.OutputResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RequestService {

    private static final Logger log = LoggerFactory.getLogger(RequestService.class);

    private final DownstreamClient downstreamClient;

    public RequestService(DownstreamClient downstreamClient) {
        this.downstreamClient = downstreamClient;
    }

    public List<OutputResponse> processRequests(List<InputRequest> inputs) {
        List<OutputResponse> results = new ArrayList<>();
        for (InputRequest input : inputs) {
            try {
                log.debug("Calling downstream for id={} payload='{}'", input.getId(), input.getPayload());
                String downstreamResult = downstreamClient.callDownstream(input.getPayload());
                results.add(new OutputResponse(input.getId(), "SUCCESS", downstreamResult));
            } catch (Exception e) {
                log.error("Downstream call failed for id={}: {}", input.getId(), e.getMessage());
                results.add(new OutputResponse(input.getId(), "FAILURE", e.getMessage()));
            }
        }
        return results;
    }
}
